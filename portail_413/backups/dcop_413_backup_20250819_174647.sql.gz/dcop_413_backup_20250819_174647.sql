--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9
-- Dumped by pg_dump version 16.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: user_role; Type: TYPE; Schema: public; Owner: dcop_user
--

CREATE TYPE public.user_role AS ENUM (
    'admin',
    'user',
    'director'
);


ALTER TYPE public.user_role OWNER TO dcop_user;

--
-- Name: visit_status; Type: TYPE; Schema: public; Owner: dcop_user
--

CREATE TYPE public.visit_status AS ENUM (
    'pending',
    'approved',
    'rejected',
    'inprogress',
    'completed',
    'cancelled'
);


ALTER TYPE public.visit_status OWNER TO dcop_user;

--
-- Name: update_statistics_updated_at(); Type: FUNCTION; Schema: public; Owner: dcop_user
--

CREATE FUNCTION public.update_statistics_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_statistics_updated_at() OWNER TO dcop_user;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: dcop_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO dcop_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _sqlx_migrations; Type: TABLE; Schema: public; Owner: dcop_user
--

CREATE TABLE public._sqlx_migrations (
    version bigint NOT NULL,
    description text NOT NULL,
    installed_on timestamp with time zone DEFAULT now() NOT NULL,
    success boolean NOT NULL,
    checksum bytea NOT NULL,
    execution_time bigint NOT NULL
);


ALTER TABLE public._sqlx_migrations OWNER TO dcop_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: dcop_user
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    action character varying(100) NOT NULL,
    resource_type character varying(50) NOT NULL,
    resource_id uuid,
    old_values jsonb,
    new_values jsonb,
    ip_address inet,
    user_agent text,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    success boolean DEFAULT true NOT NULL,
    error_message text
);


ALTER TABLE public.audit_logs OWNER TO dcop_user;

--
-- Name: TABLE audit_logs; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON TABLE public.audit_logs IS 'Table d''audit pour traçabilité complète des actions';


--
-- Name: statistics; Type: TABLE; Schema: public; Owner: dcop_user
--

CREATE TABLE public.statistics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    metric_name character varying(100) NOT NULL,
    metric_type character varying(50) NOT NULL,
    category character varying(50) NOT NULL,
    value_int bigint,
    value_float numeric(15,4) DEFAULT NULL::numeric,
    value_text text,
    value_json jsonb,
    period_start timestamp with time zone,
    period_end timestamp with time zone,
    reference_date date DEFAULT CURRENT_DATE NOT NULL,
    description text,
    unit character varying(20),
    tags text[],
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    integrity_hash character varying(64) NOT NULL
);


ALTER TABLE public.statistics OWNER TO dcop_user;

--
-- Name: TABLE statistics; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON TABLE public.statistics IS 'Table des statistiques et metriques du systeme DCOP';


--
-- Name: COLUMN statistics.metric_name; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.statistics.metric_name IS 'Nom unique de la metrique (ex: total_visits, active_users)';


--
-- Name: COLUMN statistics.metric_type; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.statistics.metric_type IS 'Type de periode (daily, weekly, monthly, yearly, real_time)';


--
-- Name: COLUMN statistics.category; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.statistics.category IS 'Categorie de la statistique (visits, users, security, system)';


--
-- Name: COLUMN statistics.value_int; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.statistics.value_int IS 'Valeur entiere de la statistique';


--
-- Name: COLUMN statistics.value_float; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.statistics.value_float IS 'Valeur decimale de la statistique';


--
-- Name: COLUMN statistics.value_text; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.statistics.value_text IS 'Valeur textuelle de la statistique';


--
-- Name: COLUMN statistics.value_json; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.statistics.value_json IS 'Donnees complexes JSON de la statistique';


--
-- Name: COLUMN statistics.integrity_hash; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.statistics.integrity_hash IS 'Hash SHA-256 pour verifier integrite des donnees';


--
-- Name: dashboard_statistics; Type: VIEW; Schema: public; Owner: dcop_user
--

CREATE VIEW public.dashboard_statistics AS
 SELECT metric_name,
    category,
    COALESCE((value_int)::text, (value_float)::text, value_text) AS display_value,
    unit,
    description,
    reference_date,
    updated_at
   FROM public.statistics
  WHERE (tags && ARRAY['dashboard'::text])
  ORDER BY category, metric_name;


ALTER VIEW public.dashboard_statistics OWNER TO dcop_user;

--
-- Name: VIEW dashboard_statistics; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON VIEW public.dashboard_statistics IS 'Vue simplifiee des statistiques pour le dashboard';


--
-- Name: users; Type: TABLE; Schema: public; Owner: dcop_user
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    username character varying(50) NOT NULL,
    password_hash text NOT NULL,
    role public.user_role DEFAULT 'user'::public.user_role NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_login timestamp with time zone,
    failed_login_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    integrity_hash character varying(128) NOT NULL,
    CONSTRAINT chk_failed_attempts CHECK (((failed_login_attempts >= 0) AND (failed_login_attempts <= 10))),
    CONSTRAINT chk_username_format CHECK (((username)::text ~ '^[a-zA-Z0-9_.-]+$'::text)),
    CONSTRAINT chk_username_length CHECK (((length((username)::text) >= 3) AND (length((username)::text) <= 50)))
);


ALTER TABLE public.users OWNER TO dcop_user;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON TABLE public.users IS 'Utilisateurs de test créés pour le développement - À SUPPRIMER EN PRODUCTION';


--
-- Name: COLUMN users.password_hash; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.users.password_hash IS 'Hash Argon2id du mot de passe';


--
-- Name: COLUMN users.integrity_hash; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.users.integrity_hash IS 'Hash SHA-512 pour vérification d''intégrité des données';


--
-- Name: visitors; Type: TABLE; Schema: public; Owner: dcop_user
--

CREATE TABLE public.visitors (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    first_name_encrypted text NOT NULL,
    last_name_encrypted text NOT NULL,
    email_encrypted text,
    phone1_encrypted text NOT NULL,
    phone2_encrypted text NOT NULL,
    phone3_encrypted text,
    phone4_encrypted text,
    organization character varying(200) NOT NULL,
    photo_data text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    integrity_hash character varying(128) NOT NULL,
    function_encrypted text,
    visit_purpose_encrypted text DEFAULT ''::text NOT NULL,
    host_name_encrypted text,
    visit_date character varying(10),
    visit_time character varying(8),
    visit_details_encrypted text,
    security_agreement boolean DEFAULT false NOT NULL,
    electronic_devices boolean,
    confidentiality boolean,
    signature_date character varying(10) DEFAULT ''::character varying NOT NULL,
    signature_data text,
    CONSTRAINT chk_organization_length CHECK (((length((organization)::text) >= 2) AND (length((organization)::text) <= 200)))
);


ALTER TABLE public.visitors OWNER TO dcop_user;

--
-- Name: TABLE visitors; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON TABLE public.visitors IS 'Table des visiteurs avec données personnelles chiffrées';


--
-- Name: COLUMN visitors.first_name_encrypted; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.visitors.first_name_encrypted IS 'Prénom chiffré avec AES-256-GCM';


--
-- Name: COLUMN visitors.last_name_encrypted; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.visitors.last_name_encrypted IS 'Nom chiffré avec AES-256-GCM';


--
-- Name: COLUMN visitors.phone1_encrypted; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.visitors.phone1_encrypted IS 'Téléphone principal (obligatoire) chiffré avec AES-256-GCM';


--
-- Name: COLUMN visitors.phone2_encrypted; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.visitors.phone2_encrypted IS 'Téléphone secondaire (obligatoire) chiffré avec AES-256-GCM';


--
-- Name: COLUMN visitors.phone3_encrypted; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.visitors.phone3_encrypted IS 'Téléphone tertiaire (optionnel) chiffré avec AES-256-GCM';


--
-- Name: COLUMN visitors.phone4_encrypted; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.visitors.phone4_encrypted IS 'Téléphone quaternaire (optionnel) chiffré avec AES-256-GCM';


--
-- Name: COLUMN visitors.function_encrypted; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.visitors.function_encrypted IS 'Fonction du visiteur (chiffrée AES-256-GCM)';


--
-- Name: COLUMN visitors.visit_purpose_encrypted; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.visitors.visit_purpose_encrypted IS 'Objectif de la visite (chiffré AES-256-GCM)';


--
-- Name: COLUMN visitors.host_name_encrypted; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.visitors.host_name_encrypted IS 'Nom de la personne à visiter (chiffré AES-256-GCM)';


--
-- Name: COLUMN visitors.visit_date; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.visitors.visit_date IS 'Date de la visite au format YYYY-MM-DD';


--
-- Name: COLUMN visitors.visit_time; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.visitors.visit_time IS 'Heure prévue au format HH:MM:SS';


--
-- Name: COLUMN visitors.visit_details_encrypted; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.visitors.visit_details_encrypted IS 'Détails supplémentaires de la visite (chiffrés AES-256-GCM)';


--
-- Name: COLUMN visitors.security_agreement; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.visitors.security_agreement IS 'Accord des consignes de sécurité (obligatoire)';


--
-- Name: COLUMN visitors.electronic_devices; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.visitors.electronic_devices IS 'Interdiction d''utiliser les appareils électroniques personnels';


--
-- Name: COLUMN visitors.confidentiality; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.visitors.confidentiality IS 'Engagement de confidentialité';


--
-- Name: COLUMN visitors.signature_date; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.visitors.signature_date IS 'Date de signature au format YYYY-MM-DD';


--
-- Name: COLUMN visitors.signature_data; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON COLUMN public.visitors.signature_data IS 'Signature numérique en base64';


--
-- Name: visits; Type: TABLE; Schema: public; Owner: dcop_user
--

CREATE TABLE public.visits (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    visitor_id uuid NOT NULL,
    purpose text NOT NULL,
    host_name character varying(100) NOT NULL,
    department character varying(100) NOT NULL,
    scheduled_start timestamp with time zone NOT NULL,
    scheduled_end timestamp with time zone NOT NULL,
    actual_start timestamp with time zone,
    actual_end timestamp with time zone,
    status public.visit_status DEFAULT 'pending'::public.visit_status NOT NULL,
    badge_number character varying(20),
    notes text,
    approved_by uuid,
    approved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    integrity_hash character varying(128) NOT NULL,
    CONSTRAINT chk_actual_dates CHECK (((actual_end IS NULL) OR (actual_start IS NULL) OR (actual_end >= actual_start))),
    CONSTRAINT chk_department_length CHECK (((length((department)::text) >= 2) AND (length((department)::text) <= 100))),
    CONSTRAINT chk_host_name_length CHECK (((length((host_name)::text) >= 2) AND (length((host_name)::text) <= 100))),
    CONSTRAINT chk_purpose_length CHECK ((length(purpose) >= 5)),
    CONSTRAINT chk_scheduled_dates CHECK ((scheduled_end > scheduled_start))
);


ALTER TABLE public.visits OWNER TO dcop_user;

--
-- Name: TABLE visits; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON TABLE public.visits IS 'Table des visites avec suivi complet du cycle de vie';


--
-- Data for Name: _sqlx_migrations; Type: TABLE DATA; Schema: public; Owner: dcop_user
--

COPY public._sqlx_migrations (version, description, installed_on, success, checksum, execution_time) FROM stdin;
1	initial schema	2025-08-15 14:33:39.953107+00	t	\\x02fcf95c3fa0dc357ba948953aea07434c6c0474511138f33791928792f5f2353c2185725ed5b5c26d48be21a2cf446f	216442832
2	seed data	2025-08-15 14:33:40.177532+00	t	\\xe88a5d6de6acbae389ae59af0c420f3ddcbde8e2049ef7d674fd2ac011ff525a0902a72f6a47fe9babdb0974c973b310	10175626
3	add visitor form fields	2025-08-15 14:33:40.195081+00	t	\\xf2a6e7f855985979ff7f872a65d2b696af354c9e07a6af63f6ff6e420c567cf6a9d631c31c3f8f53b391f3b2e3c462f6	36647409
4	create statistics table	2025-08-15 14:33:40.240084+00	t	\\x482b195d36efedc12179d35a3ed1d2407b9bd2ed764786bb9432da06f0870c8da6aaefe86fb45b8dd1c02bc62af5e3b0	105750089
5	add statistics unique constraint	2025-08-15 14:33:40.353015+00	t	\\xb94359dad6e70567e1d76fc62483a641100bb9d62d287b83e23bd03c6683f8bb1c958fdb7a6b066d3d6ea277c6bf8bb0	17108593
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: dcop_user
--

COPY public.audit_logs (id, user_id, action, resource_type, resource_id, old_values, new_values, ip_address, user_agent, "timestamp", success, error_message) FROM stdin;
d3bf0413-5aca-4508-b4df-703a9431be0c	00aec494-7f26-49d7-a7a7-6fa11c2781a4	LOGIN_SUCCESS	User	00aec494-7f26-49d7-a7a7-6fa11c2781a4	\N	\N	127.0.0.1	curl/8.12.1	2025-08-16 15:27:03.519628+00	t	\N
37d7df03-954d-47bd-9385-51160f0ffa04	00aec494-7f26-49d7-a7a7-6fa11c2781a4	LOGIN_SUCCESS	User	00aec494-7f26-49d7-a7a7-6fa11c2781a4	\N	\N	172.25.2.2	curl/8.14.1	2025-08-16 15:27:26.891163+00	t	\N
ce99c206-240f-49af-8600-68cd4dff27fd	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 15:30:01.065825+00	t	\N
b07b9182-5fe8-4d65-90e4-a58036695ea0	00aec494-7f26-49d7-a7a7-6fa11c2781a4	LOGIN_SUCCESS	User	00aec494-7f26-49d7-a7a7-6fa11c2781a4	\N	\N	172.25.2.2	curl/8.14.1	2025-08-16 15:30:48.872092+00	t	\N
b45e7c70-1cec-4501-993b-6e851782fa90	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 15:33:13.711938+00	t	\N
af292217-6121-4123-8a43-bcd1be7c871b	00000000-0000-0000-0000-000000000004	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000004	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 15:33:37.084912+00	t	\N
28a9d16b-77c9-4a16-8a2f-c64be8ad78b8	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 15:41:46.221538+00	t	\N
2bf8cdff-807c-4fd8-b6e8-fe411dc61c11	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 15:50:26.618114+00	t	\N
d67df56f-cacd-42cf-b1d2-e8287f7c0832	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 15:50:29.248482+00	t	\N
0f5c46eb-fd90-4e55-baaf-01bfd8ce253e	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 15:50:30.397585+00	t	\N
4f93712e-87c2-4070-b1cb-1d412380b07b	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 15:50:31.505097+00	t	\N
6a087367-6065-42c0-9bf7-6e450dd931a8	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 15:50:32.465225+00	t	\N
0758a53c-5eb2-4679-8563-5d3f092a2bbe	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 15:50:33.526765+00	t	\N
6ba90718-b330-4b2b-9787-536d04e222e7	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 15:50:34.464298+00	t	\N
3f8eb0b8-512d-462f-b821-9d3da5ef77e5	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 15:50:35.395407+00	t	\N
a154d686-5a0c-4013-b648-b74d0e4b46fb	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 15:50:41.329099+00	t	\N
5f61ccdc-57c5-468a-a8be-cdb3a8b0a1e0	00000000-0000-0000-0000-000000000004	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000004	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 15:50:41.599147+00	t	\N
a1660f3d-7d50-45be-998a-655aa34c4be0	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 15:51:37.788267+00	t	\N
867fdadc-3096-40f8-afcd-d2ab9496975d	00000000-0000-0000-0000-000000000004	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000004	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 15:51:38.050937+00	t	\N
4513d590-fab6-40a1-aa43-5552eabd62e3	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 15:56:55.102792+00	t	\N
da4f9d2c-d478-4b95-9800-765b450e416a	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 15:57:04.213875+00	t	\N
6c10610f-7f57-49a0-be66-f69fa4260a78	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 15:58:51.26468+00	t	\N
b8aa59b3-0082-4e12-872a-7c8ce940a7f8	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 16:12:47.050913+00	t	\N
37ca0d97-4358-4219-a039-1dfd69c81f42	00000000-0000-0000-0000-000000000004	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000004	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 16:12:59.83564+00	t	\N
c4676447-f0ba-4137-8c76-dc457d933709	00000000-0000-0000-0000-000000000003	LOGIN_ATTEMPT	User	00000000-0000-0000-0000-000000000003	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 16:22:11.793274+00	f	Invalid password
160b7034-fd61-4329-9429-bf8625a65b4a	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 16:25:00.634956+00	t	\N
13481176-046d-4d9d-8ee1-dbe1e72f9d26	00000000-0000-0000-0000-000000000004	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000004	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 16:25:07.740074+00	t	\N
e4f16486-811e-4aef-bc26-44199b1ecc0f	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 16:38:20.744649+00	t	\N
9d845a64-a88b-496b-a44a-5a3c1c9a49eb	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 16:41:23.043229+00	t	\N
dd583d94-0a1d-462a-b121-369570ea1527	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 16:42:03.247676+00	t	\N
7cce7185-37c5-4c58-b760-61faf33e1f8b	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 16:42:25.892276+00	t	\N
5b6398b1-e1ae-4829-adcd-7850bdb73222	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 16:42:47.212208+00	t	\N
b4216262-773d-4634-b0fc-b95b19c2dbc6	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 16:44:36.831313+00	t	\N
40f40897-3472-4686-ba7a-4ab1b5edba8a	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 16:52:03.057785+00	t	\N
ecaa07ef-0d3b-4c1b-befc-ce33b2dc2e5c	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 16:52:32.817519+00	t	\N
e0a62a22-2ef0-405b-a04b-81db9b39f792	00000000-0000-0000-0000-000000000001	LOGIN_ATTEMPT	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 17:04:54.976249+00	f	Invalid password
0a52bbae-8f92-4aa8-949b-6137cdba96ca	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 17:05:32.002427+00	t	\N
01112611-bad1-40c0-8dd1-59ed31b0e1a8	00000000-0000-0000-0000-000000000005	LOGIN_ATTEMPT	User	00000000-0000-0000-0000-000000000005	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 17:05:58.157983+00	f	Invalid password
b37aece1-30a8-413d-9ae2-b16853b9d0e5	00000000-0000-0000-0000-000000000005	LOGIN_ATTEMPT	User	00000000-0000-0000-0000-000000000005	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 17:06:09.046466+00	f	Invalid password
ab02680b-1f9e-4708-a975-6524357cef38	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 17:06:53.47268+00	t	\N
bb867391-b073-4014-8178-86ce1f08a991	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 17:06:58.125171+00	t	\N
d3562034-75b8-4257-a95b-a669b2ac4355	00000000-0000-0000-0000-000000000004	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000004	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 17:07:11.657124+00	t	\N
b6de6a62-75a0-43d2-bec1-a0b17d02940f	00000000-0000-0000-0000-000000000004	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000004	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 17:07:13.56048+00	t	\N
f49fa401-ffff-4648-a789-7f0e02ce84b6	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 17:23:02.815589+00	t	\N
7f8a62f9-34d9-4bbf-924a-0d1ec9a4da90	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 17:39:02.936297+00	t	\N
16479562-e387-4ffa-a48a-772e5abfe732	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 18:13:28.307696+00	t	\N
6e96b3a8-6dd9-4276-92ff-c19f1acfe982	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 18:20:38.699807+00	t	\N
c918312f-bab9-4d73-9361-0d5bff8dbef3	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 18:22:14.620601+00	t	\N
9908e31d-8263-486e-9fda-5ffd71ea14ba	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 18:25:05.904445+00	t	\N
85843e03-1fd7-4965-95e2-247a4c343e16	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 18:29:51.391815+00	t	\N
6331be8a-c56b-4a02-b063-8f26cfe20327	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 18:32:03.649555+00	t	\N
5179a62a-668b-42f2-8526-00132f0ef89b	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 18:32:33.300464+00	t	\N
5d9c77f1-8a9d-4a09-a10d-3cce250d622c	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 18:33:31.154693+00	t	\N
669b14b5-b7c4-4790-a6a1-31bcb650a67d	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 18:37:23.550664+00	t	\N
25b86ea0-65f6-455c-885c-35fe9b55c173	00aec494-7f26-49d7-a7a7-6fa11c2781a4	LOGIN_SUCCESS	User	00aec494-7f26-49d7-a7a7-6fa11c2781a4	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 18:37:29.896315+00	t	\N
89c3e794-ef12-4268-aa7d-20be3ff2eaf6	00aec494-7f26-49d7-a7a7-6fa11c2781a4	LOGIN_SUCCESS	User	00aec494-7f26-49d7-a7a7-6fa11c2781a4	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 19:36:14.046081+00	t	\N
3841c8d4-b9e3-4155-8b0b-b3f09dddd6bd	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 19:36:28.021067+00	t	\N
22c50ba1-933c-49e9-be21-d072931c492e	00aec494-7f26-49d7-a7a7-6fa11c2781a4	LOGIN_SUCCESS	User	00aec494-7f26-49d7-a7a7-6fa11c2781a4	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 19:48:25.227941+00	t	\N
f6916ced-50e8-4b93-977a-acf8f610c225	00aec494-7f26-49d7-a7a7-6fa11c2781a4	LOGIN_SUCCESS	User	00aec494-7f26-49d7-a7a7-6fa11c2781a4	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 19:49:33.944858+00	t	\N
865be099-dc20-4872-ba4b-d8aba83c2266	00aec494-7f26-49d7-a7a7-6fa11c2781a4	LOGIN_ATTEMPT	User	00aec494-7f26-49d7-a7a7-6fa11c2781a4	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 19:49:34.223832+00	f	Invalid password
42dc0949-5255-4769-9b9b-a2e989d9109c	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 19:52:45.936352+00	t	\N
2cdf876a-89f0-4b3a-bbf2-e03a21b664e3	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 19:53:16.276306+00	t	\N
edac2534-d513-44ee-9319-d61adb15897a	00aec494-7f26-49d7-a7a7-6fa11c2781a4	LOGIN_SUCCESS	User	00aec494-7f26-49d7-a7a7-6fa11c2781a4	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 19:53:52.829037+00	t	\N
5bc0bb4e-5ef3-49b5-ab31-323566bb5336	00aec494-7f26-49d7-a7a7-6fa11c2781a4	LOGIN_ATTEMPT	User	00aec494-7f26-49d7-a7a7-6fa11c2781a4	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 19:53:53.09819+00	f	Invalid password
e4960b33-a80b-45a7-a41d-cb5b6fa0b023	00aec494-7f26-49d7-a7a7-6fa11c2781a4	LOGIN_SUCCESS	User	00aec494-7f26-49d7-a7a7-6fa11c2781a4	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 19:59:13.450772+00	t	\N
003e1872-b078-44d2-8475-a32e5058178c	00aec494-7f26-49d7-a7a7-6fa11c2781a4	LOGIN_ATTEMPT	User	00aec494-7f26-49d7-a7a7-6fa11c2781a4	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 19:59:13.722108+00	f	Invalid password
c315cc37-fff0-4577-82d2-cd2c15f4faae	00aec494-7f26-49d7-a7a7-6fa11c2781a4	LOGIN_SUCCESS	User	00aec494-7f26-49d7-a7a7-6fa11c2781a4	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 20:01:23.492843+00	t	\N
fbecee65-6094-4612-863e-3d4381d167e0	00aec494-7f26-49d7-a7a7-6fa11c2781a4	LOGIN_SUCCESS	User	00aec494-7f26-49d7-a7a7-6fa11c2781a4	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 20:04:16.775367+00	t	\N
8efe684e-a796-438f-a88c-264453fa5825	00aec494-7f26-49d7-a7a7-6fa11c2781a4	LOGIN_SUCCESS	User	00aec494-7f26-49d7-a7a7-6fa11c2781a4	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 20:04:28.013875+00	t	\N
db4a6da0-0185-4404-b58a-a41da9b8d09e	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-16 20:08:02.839941+00	t	\N
d4210b74-5aab-4224-b209-1d1291dc91e6	00aec494-7f26-49d7-a7a7-6fa11c2781a4	LOGIN_SUCCESS	User	00aec494-7f26-49d7-a7a7-6fa11c2781a4	\N	\N	172.25.2.1	curl/8.14.1	2025-08-16 20:09:16.147011+00	t	\N
13139f00-f548-4779-9cb2-499bc0ba4121	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-18 19:00:15.697424+00	t	\N
27777093-3d00-405b-9966-a55272fdb7c2	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-18 19:08:57.796345+00	t	\N
89cd2162-9a90-4d07-b467-b3a56e5c41ea	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-18 19:09:17.828964+00	t	\N
a73874ac-0ca2-4f77-80ea-c8575ca678a2	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-18 19:16:06.42678+00	t	\N
beff6027-c827-4d8b-91e2-c8e06a3dcf52	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-18 19:17:48.34717+00	t	\N
8aae8f90-a3b7-467b-b14d-f2ffc126279b	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-18 19:35:27.377479+00	t	\N
0408d490-09d4-4f17-bb2c-20d3e6ac1288	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-18 19:44:18.500693+00	t	\N
cb27812d-b4ca-4bc7-acee-8f232c7584c3	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-18 20:02:34.133374+00	t	\N
b4c3fe08-2409-4080-be44-2e2e128f82cc	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-18 20:20:27.756612+00	t	\N
8ddf4695-b906-42fb-a8e2-b236f3149020	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-18 20:26:02.169649+00	t	\N
79a03486-7dc5-4dfe-951f-0791f3c242ef	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	curl/8.14.1	2025-08-18 20:47:56.572794+00	t	\N
ef5e8fbe-45e7-48f3-b910-b28d0b5b5009	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-18 20:53:24.625231+00	t	\N
63d82ffc-b57c-49b3-962b-0b095ea86e8c	00000000-0000-0000-0000-000000000004	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000004	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-18 20:55:07.90651+00	t	\N
498d81f4-05b2-4f5b-b191-1aafb9c1d056	00000000-0000-0000-0000-000000000001	LOGIN_SUCCESS	User	00000000-0000-0000-0000-000000000001	\N	\N	172.25.2.1	Mozilla/5.0 (X11; Linux x86_64; rv:141.0) Gecko/20100101 Firefox/141.0	2025-08-18 21:07:18.977001+00	t	\N
\.


--
-- Data for Name: statistics; Type: TABLE DATA; Schema: public; Owner: dcop_user
--

COPY public.statistics (id, metric_name, metric_type, category, value_int, value_float, value_text, value_json, period_start, period_end, reference_date, description, unit, tags, created_at, updated_at, created_by, integrity_hash) FROM stdin;
336dd006-87d2-47f9-a56d-7b2e2df2ed91	total_visits_today	daily	visits	0	\N	\N	\N	\N	\N	2025-08-15	Nombre total de visites pour aujourd hui	count	{visits,daily,dashboard}	2025-08-15 14:33:40.240084+00	2025-08-15 14:33:40.240084+00	\N	b471118ed1cd1c1123de96fad2bebe7451a8f4dd52626f429734a26195350bd0
a8824b1a-edff-4354-9929-58521d18bf3c	active_visits_now	real_time	visits	0	\N	\N	\N	\N	\N	2025-08-15	Nombre de visites actuellement en cours	count	{visits,real_time,dashboard}	2025-08-15 14:33:40.240084+00	2025-08-15 14:33:40.240084+00	\N	deee9c5e4fcaec924921ecedf5077cfcbdb600a57547e564bee0afe8fa8f48c5
2472a9e8-9432-40e9-a4db-2198763a2ce0	total_users	real_time	users	3	\N	\N	\N	\N	\N	2025-08-15	Nombre total d utilisateurs actifs	count	{users,total,dashboard}	2025-08-15 14:33:40.240084+00	2025-08-15 14:33:40.240084+00	\N	1a9816093040c18f14f19cdcc353e263f7d2960e27a099d6305a36230faf6f86
d943ab9b-da88-4f59-9e6f-ad3d3978f7e5	total_visitors	real_time	visits	2	\N	\N	\N	\N	\N	2025-08-15	Nombre total de visiteurs enregistres	count	{visitors,total,dashboard}	2025-08-15 14:33:40.240084+00	2025-08-15 14:33:40.240084+00	\N	6482f2b270e9069b3e8723ed5c77d81f8589080e42484dc280db0c300da4bf90
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: dcop_user
--

COPY public.users (id, username, password_hash, role, is_active, last_login, failed_login_attempts, locked_until, created_at, updated_at, integrity_hash) FROM stdin;
00000000-0000-0000-0000-000000000002	admin_security	$2b$12$qtHTWp3aNxruffZKq1HGm.iOgBZ4sKYWTMlpDhpKgKSTdMR8OUNDC	admin	t	\N	0	\N	2025-08-15 14:42:52.558269+00	2025-08-15 14:42:52.558269+00	hash2
00000000-0000-0000-0000-000000000006	user_manager	$2b$12$5WLFdPQLSYSi1QWWWO.Z3.ZocYyfTTDQ/.n0n6nF7oKCllIymF6vC	user	t	\N	0	\N	2025-08-15 14:42:52.558269+00	2025-08-15 14:42:52.558269+00	hash6
00000000-0000-0000-0000-000000000007	test_user1	$2b$12$seYUo3b2bznSzcu5ZIyo/u1V4lkhQoWxIcOpXiIdjR2.z7U652pIy	user	t	\N	0	\N	2025-08-15 14:42:52.558269+00	2025-08-15 14:42:52.558269+00	hash7
00000000-0000-0000-0000-000000000008	test_user2	$2b$12$9xYxO1ZCy1.KlvSuJxXYhecuNuJFCdBKX5npMpA85Ts8xmd9zBOUi	user	t	\N	0	\N	2025-08-15 14:42:52.558269+00	2025-08-15 14:42:52.558269+00	hash8
00000000-0000-0000-0000-000000000005	user_security	$2b$12$4.EX4IUKiu9DCVCD7krcbOSMIqKGM2ymNyzTz/vuh01TMmhMrxJva	user	t	\N	2	\N	2025-08-15 14:42:52.558269+00	2025-08-16 17:06:09.030566+00	hash5
00aec494-7f26-49d7-a7a7-6fa11c2781a4	admin	$2b$12$zA8QPhrz6lmTHyo2LkyW2..nblPs5SkjO7Ej1hY21p8BRBDRZtedO	admin	t	2025-08-16 20:09:16.130038+00	0	\N	2025-08-16 15:12:20.843975+00	2025-08-16 20:09:16.130744+00	f038c9b49689fc99e88df84eb6781ada5f73efbbb0a57cb07981a5e3eba740367a10f47b77409d366eef4a08380f513f9b2c9785ba474ea013d3eb081fedd3b2
00000000-0000-0000-0000-000000000003	admin_system	$2b$12$5ti1FvfROtK8IitO4JAuo.k./BCIFPveGDFSRaRul4cONOoQxD22G	admin	t	\N	1	\N	2025-08-15 14:42:52.558269+00	2025-08-16 16:22:11.777357+00	hash3
00000000-0000-0000-0000-000000000004	user_reception	$2b$12$cnmhM5x5radnri2ZRLPmF.OfZp65NcgCD69TOUhl69Ilggp4kIZFm	user	t	2025-08-18 20:55:07.890548+00	0	\N	2025-08-15 14:42:52.558269+00	2025-08-18 20:55:07.890802+00	hash4
00000000-0000-0000-0000-000000000001	admin_dcop	$2b$12$NSyoxZvTyZovCcr2B0H.Y.1t00PZ5.Ix7DJ9zY.la939D56/p9Vx6	admin	t	2025-08-18 21:07:18.960714+00	0	\N	2025-08-15 14:42:52.558269+00	2025-08-18 21:07:18.961189+00	hash1
\.


--
-- Data for Name: visitors; Type: TABLE DATA; Schema: public; Owner: dcop_user
--

COPY public.visitors (id, first_name_encrypted, last_name_encrypted, email_encrypted, phone1_encrypted, phone2_encrypted, phone3_encrypted, phone4_encrypted, organization, photo_data, created_at, updated_at, integrity_hash, function_encrypted, visit_purpose_encrypted, host_name_encrypted, visit_date, visit_time, visit_details_encrypted, security_agreement, electronic_devices, confidentiality, signature_date, signature_data) FROM stdin;
\.


--
-- Data for Name: visits; Type: TABLE DATA; Schema: public; Owner: dcop_user
--

COPY public.visits (id, visitor_id, purpose, host_name, department, scheduled_start, scheduled_end, actual_start, actual_end, status, badge_number, notes, approved_by, approved_at, created_at, updated_at, integrity_hash) FROM stdin;
\.


--
-- Name: _sqlx_migrations _sqlx_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: dcop_user
--

ALTER TABLE ONLY public._sqlx_migrations
    ADD CONSTRAINT _sqlx_migrations_pkey PRIMARY KEY (version);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: dcop_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: statistics statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: dcop_user
--

ALTER TABLE ONLY public.statistics
    ADD CONSTRAINT statistics_pkey PRIMARY KEY (id);


--
-- Name: statistics uk_statistics_metric_date; Type: CONSTRAINT; Schema: public; Owner: dcop_user
--

ALTER TABLE ONLY public.statistics
    ADD CONSTRAINT uk_statistics_metric_date UNIQUE (metric_name, reference_date);


--
-- Name: CONSTRAINT uk_statistics_metric_date ON statistics; Type: COMMENT; Schema: public; Owner: dcop_user
--

COMMENT ON CONSTRAINT uk_statistics_metric_date ON public.statistics IS 'Contrainte unique pour permettre ON CONFLICT dans les insertions de statistiques';


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: dcop_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: dcop_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: visitors visitors_pkey; Type: CONSTRAINT; Schema: public; Owner: dcop_user
--

ALTER TABLE ONLY public.visitors
    ADD CONSTRAINT visitors_pkey PRIMARY KEY (id);


--
-- Name: visits visits_badge_number_key; Type: CONSTRAINT; Schema: public; Owner: dcop_user
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_badge_number_key UNIQUE (badge_number);


--
-- Name: visits visits_pkey; Type: CONSTRAINT; Schema: public; Owner: dcop_user
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_logs_resource_type; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_audit_logs_resource_type ON public.audit_logs USING btree (resource_type);


--
-- Name: idx_audit_logs_success; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_audit_logs_success ON public.audit_logs USING btree (success);


--
-- Name: idx_audit_logs_timestamp; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_audit_logs_timestamp ON public.audit_logs USING btree ("timestamp");


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: idx_statistics_category; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_statistics_category ON public.statistics USING btree (category);


--
-- Name: idx_statistics_category_date; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_statistics_category_date ON public.statistics USING btree (category, reference_date);


--
-- Name: idx_statistics_created_at; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_statistics_created_at ON public.statistics USING btree (created_at);


--
-- Name: idx_statistics_metric_name; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_statistics_metric_name ON public.statistics USING btree (metric_name);


--
-- Name: idx_statistics_metric_period; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_statistics_metric_period ON public.statistics USING btree (metric_name, reference_date, metric_type);


--
-- Name: idx_statistics_metric_type; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_statistics_metric_type ON public.statistics USING btree (metric_type);


--
-- Name: idx_statistics_period; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_statistics_period ON public.statistics USING btree (period_start, period_end);


--
-- Name: idx_statistics_reference_date; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_statistics_reference_date ON public.statistics USING btree (reference_date);


--
-- Name: idx_users_is_active; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_users_is_active ON public.users USING btree (is_active);


--
-- Name: idx_users_locked_until; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_users_locked_until ON public.users USING btree (locked_until);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: idx_visitors_created_at; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_visitors_created_at ON public.visitors USING btree (created_at);


--
-- Name: idx_visitors_organization; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_visitors_organization ON public.visitors USING btree (organization);


--
-- Name: idx_visitors_security_agreement; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_visitors_security_agreement ON public.visitors USING btree (security_agreement);


--
-- Name: idx_visitors_signature_date; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_visitors_signature_date ON public.visitors USING btree (signature_date);


--
-- Name: idx_visitors_visit_date; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_visitors_visit_date ON public.visitors USING btree (visit_date) WHERE (visit_date IS NOT NULL);


--
-- Name: idx_visits_badge_number; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_visits_badge_number ON public.visits USING btree (badge_number);


--
-- Name: idx_visits_department; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_visits_department ON public.visits USING btree (department);


--
-- Name: idx_visits_scheduled_start; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_visits_scheduled_start ON public.visits USING btree (scheduled_start);


--
-- Name: idx_visits_status; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_visits_status ON public.visits USING btree (status);


--
-- Name: idx_visits_visitor_id; Type: INDEX; Schema: public; Owner: dcop_user
--

CREATE INDEX idx_visits_visitor_id ON public.visits USING btree (visitor_id);


--
-- Name: statistics trigger_statistics_updated_at; Type: TRIGGER; Schema: public; Owner: dcop_user
--

CREATE TRIGGER trigger_statistics_updated_at BEFORE UPDATE ON public.statistics FOR EACH ROW EXECUTE FUNCTION public.update_statistics_updated_at();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: dcop_user
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: visitors update_visitors_updated_at; Type: TRIGGER; Schema: public; Owner: dcop_user
--

CREATE TRIGGER update_visitors_updated_at BEFORE UPDATE ON public.visitors FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: visits update_visits_updated_at; Type: TRIGGER; Schema: public; Owner: dcop_user
--

CREATE TRIGGER update_visits_updated_at BEFORE UPDATE ON public.visits FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dcop_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: statistics statistics_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dcop_user
--

ALTER TABLE ONLY public.statistics
    ADD CONSTRAINT statistics_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: visits visits_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dcop_user
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: visits visits_visitor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dcop_user
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_visitor_id_fkey FOREIGN KEY (visitor_id) REFERENCES public.visitors(id) ON DELETE CASCADE;


--
-- Name: audit_logs; Type: ROW SECURITY; Schema: public; Owner: dcop_user
--

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: dcop_user
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: visitors; Type: ROW SECURITY; Schema: public; Owner: dcop_user
--

ALTER TABLE public.visitors ENABLE ROW LEVEL SECURITY;

--
-- Name: visits; Type: ROW SECURITY; Schema: public; Owner: dcop_user
--

ALTER TABLE public.visits ENABLE ROW LEVEL SECURITY;

--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO app_user;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.armor(bytea) TO app_user;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.armor(bytea, text[], text[]) TO app_user;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.crypt(text, text) TO app_user;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.dearmor(text) TO app_user;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.decrypt(bytea, bytea, text) TO app_user;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.decrypt_iv(bytea, bytea, bytea, text) TO app_user;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.digest(bytea, text) TO app_user;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.digest(text, text) TO app_user;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.encrypt(bytea, bytea, text) TO app_user;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.encrypt_iv(bytea, bytea, bytea, text) TO app_user;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.gen_random_bytes(integer) TO app_user;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.gen_random_uuid() TO app_user;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.gen_salt(text) TO app_user;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.gen_salt(text, integer) TO app_user;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.hmac(bytea, bytea, text) TO app_user;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.hmac(text, text, text) TO app_user;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_armor_headers(text, OUT key text, OUT value text) TO app_user;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_key_id(bytea) TO app_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea) TO app_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea, text) TO app_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea, text, text) TO app_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea) TO app_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text) TO app_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO app_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt(text, bytea) TO app_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt(text, bytea, text) TO app_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea) TO app_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea, text) TO app_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt(bytea, text) TO app_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt(bytea, text, text) TO app_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt_bytea(bytea, text) TO app_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt_bytea(bytea, text, text) TO app_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt(text, text) TO app_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt(text, text, text) TO app_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt_bytea(bytea, text) TO app_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt_bytea(bytea, text, text) TO app_user;


--
-- Name: FUNCTION update_statistics_updated_at(); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.update_statistics_updated_at() TO app_user;


--
-- Name: FUNCTION update_updated_at_column(); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.update_updated_at_column() TO app_user;


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.uuid_generate_v1() TO app_user;


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.uuid_generate_v1mc() TO app_user;


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.uuid_generate_v3(namespace uuid, name text) TO app_user;


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.uuid_generate_v4() TO app_user;


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.uuid_generate_v5(namespace uuid, name text) TO app_user;


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.uuid_nil() TO app_user;


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.uuid_ns_dns() TO app_user;


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.uuid_ns_oid() TO app_user;


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.uuid_ns_url() TO app_user;


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: public; Owner: dcop_user
--

GRANT ALL ON FUNCTION public.uuid_ns_x500() TO app_user;


--
-- Name: TABLE _sqlx_migrations; Type: ACL; Schema: public; Owner: dcop_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public._sqlx_migrations TO app_user;


--
-- Name: TABLE audit_logs; Type: ACL; Schema: public; Owner: dcop_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.audit_logs TO app_user;


--
-- Name: TABLE statistics; Type: ACL; Schema: public; Owner: dcop_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.statistics TO app_user;


--
-- Name: TABLE dashboard_statistics; Type: ACL; Schema: public; Owner: dcop_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.dashboard_statistics TO app_user;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: dcop_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.users TO app_user;


--
-- Name: TABLE visitors; Type: ACL; Schema: public; Owner: dcop_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.visitors TO app_user;


--
-- Name: TABLE visits; Type: ACL; Schema: public; Owner: dcop_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.visits TO app_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: dcop_user
--

ALTER DEFAULT PRIVILEGES FOR ROLE dcop_user IN SCHEMA public GRANT SELECT,USAGE ON SEQUENCES TO app_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: dcop_user
--

ALTER DEFAULT PRIVILEGES FOR ROLE dcop_user IN SCHEMA public GRANT ALL ON FUNCTIONS TO app_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: dcop_user
--

ALTER DEFAULT PRIVILEGES FOR ROLE dcop_user IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO app_user;


--
-- PostgreSQL database dump complete
--

